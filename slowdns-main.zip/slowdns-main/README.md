# To Install
``` bash 
curl -skLO -H "Authorization: token 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" -H "Accept: application/vnd.github.v3.raw" "https://raw.githubusercontent.com/nagbabalik/slowdns/main/install.sh" && chmod +x install.sh && bash install.sh
```
